public class Account {

    int accountid;
    String iban;
    double balance;
    int clientid;

//    Client cliente;

    public Account(int accountid, String iban, double balance, int clientid) {
        this.accountid = accountid;
        this.iban = iban;
        this.balance = balance;
        this.clientid = clientid;
//        this.cliente = cliente;
    }

    @Override
    public String toString() {
        return "Account{" +
                "accountid=" + accountid +
                ", iban='" + iban + '\'' +
                ", balance=" + balance +
                ", clientid=" + clientid +
                '}';
    }

    public int getAccountid() {
        return accountid;
    }

    public void setAccountid(int accountid) {
        this.accountid = accountid;
    }

    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public int getClientid() {
        return clientid;
    }

    public void setClientid(int clientid) {
        this.clientid = clientid;
    }

//    public Client getCliente() {
//        return cliente;
//    }
//
//    public void setCliente(Client cliente) {
//        this.cliente = cliente;
//    }
}
