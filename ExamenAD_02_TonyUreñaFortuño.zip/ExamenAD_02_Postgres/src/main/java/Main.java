import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.codecs.configuration.CodecProvider;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.List;

import static com.mongodb.MongoClientSettings.getDefaultCodecRegistry;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

public class Main {

    public static void main(String[] args) {

        String urlConexion = "jdbc:postgresql://examenad.ci66saah1axn.us-east-1.rds.amazonaws.com:5432/urefor";
        String usuario = "postgres";
        String password = "qwerty1234";

        List<Client> listaClientes;

        try (Connection conexion = DriverManager.getConnection(urlConexion, usuario, password)) {

            // Crea cuenta
            OperacionesCRUD.creaCuenta(conexion, new Account(666, "1234567890", 125.2, 1));
            OperacionesCRUD.creaCuenta(conexion, new Account(999, "0987654321", 125.2, 1));

            // Borra cuenta
            OperacionesCRUD.borraCuenta(conexion, 999);

            // Modifica cuenta
            OperacionesCRUD.modificaCuenta(conexion, 666, new Account(666, "5555555555", 555.5, 2));

            // Muestra cuenta
            OperacionesCRUD.muestraCuenta(conexion, 666);

            // Muestra todas las cuentas
            OperacionesCRUD.muestraTodasCuentas(conexion).stream().forEach(p -> {
                System.out.println(p.toString());
            });

            try {
                conexion.setAutoCommit(false);

                OperacionesCRUD.transaction(conexion, "ES1600812569102753685295", "ES2720956691119558361144", 1000);

                conexion.setAutoCommit(true);

            } catch (SQLException ex1) {
                System.err.println(ex1.getClass().getName() + ": " + ex1.getMessage());
                try {
                    conexion.rollback();
                    System.err.println("ROLLBACK ejecutado");
                } catch (SQLException ex2) {
                    System.err.println("Error haciendo ROLLBACK");
                }
            }

            ///////////////////////////////////////////////////////////
            // BORRAR ESTO
            ////////////////////////////////////////////////////////
            OperacionesCRUD.borraCuenta(conexion, 666);

        } catch (SQLException ex) {
            System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
        }

        Logger logger = LoggerFactory.getLogger("org.mongodb.driver");

        String uri = "mongodb://urefor:qwerty1234@ec2-54-146-188-92.compute-1.amazonaws.com:27017";
        String baseDatos = "urefor";
        String coleccion = "clients";

        try (MongoClient mongoClient = MongoClients.create(uri)) {
            CodecProvider pojoCodecProvider = PojoCodecProvider.builder().automatic(true).build();
            CodecRegistry pojoCodecRegistry = fromRegistries(getDefaultCodecRegistry(), fromProviders(pojoCodecProvider));

            MongoDatabase database = mongoClient.getDatabase(baseDatos).withCodecRegistry(pojoCodecRegistry);
            MongoCollection<Client> collection = database.getCollection(coleccion, Client.class);

            // Muestra Cliente
            System.out.println(OperacionesCRUD.muestraCliente(collection, 1).toString());

            // Crea cliente
            OperacionesCRUD.creaCliente(collection, new Client("231212", "paco", "paquito paquete", "Kazajistán", "65654654", "paco420", "paco420@cosas.com", "pquitoelmillor"));

            // Borra cliente
            OperacionesCRUD.borraCliente(collection, "231212");

            // Modifica cliente
            OperacionesCRUD.modificaCliente(collection, "231212", new Client("231212", "paconzio", "paquito paquete paquetero paqueton", "Kazajistán", "65654654", "paco420", "paco420@cosas.com", "pquitoelmillor"));

        }

    }

}
