import com.mongodb.client.MongoCollection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static com.mongodb.client.model.Filters.*;

public class OperacionesCRUD {

    // Crea cuenta
    public static void creaCuenta(Connection conexion, Account cuenta){
        String consultaSQL = "INSERT INTO accounts (accountid, iban, balance, clientid)" +
                "VALUES (?,?,?,?)";
        try {
            PreparedStatement consulta = conexion.prepareStatement(consultaSQL);

            consulta.setInt(1, cuenta.getAccountid());
            consulta.setString(2, cuenta.getIban());
            consulta.setDouble(3, cuenta.getBalance());
            consulta.setInt(4, cuenta.getClientid());

            consulta.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Crea cliente
    public static void creaCliente(MongoCollection<Client> collection, Client cliente){
        collection.insertOne(cliente);
    }

    // Borra cuenta
    public static void borraCuenta(Connection conexion, int numeroCuenta){
        String consultaSQL = "DELETE FROM accounts WHERE accountid = ?";
        try {
            PreparedStatement consulta = conexion.prepareStatement(consultaSQL);

            consulta.setInt(1, numeroCuenta);

            consulta.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Borra cliente
    public static void borraCliente(MongoCollection<Client> collection, String dniCliente){
        collection.deleteOne(eq("dni",dniCliente));
    }

    // Modifica cuenta
    public static void modificaCuenta(Connection conexion, int idCuenta, Account cuentaModificada){
        String consultaSQL = "UPDATE accounts " +
                "SET iban = ?, " +
                "balance = ?, " +
                "clientid = ? " +
                "WHERE accountid = ?";
        try {
            PreparedStatement consulta = conexion.prepareStatement(consultaSQL);

            consulta.setString(1, cuentaModificada.getIban());
            consulta.setDouble(2, cuentaModificada.getBalance());
            consulta.setInt(3, cuentaModificada.getClientid());
            consulta.setInt(4, idCuenta);

            consulta.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Modifica Cliente
    public static void modificaCliente(MongoCollection<Client> collection, String dniCliente, Client cliente){
        collection.replaceOne(eq("dni", dniCliente), cliente);
    }

    // Muestra cuenta
    public static void muestraCuenta(Connection conexion, int idCuenta){
        String consultaSQL = "SELECT * FROM accounts " +
                "WHERE ? = accountid";
        try {
            PreparedStatement consulta = conexion.prepareStatement(consultaSQL);

            consulta.setInt(1, idCuenta);

            ResultSet resultados = consulta.executeQuery();

                while(resultados.next()){
                    System.out.println(
                            resultados.getInt("accountid") + "\t|\t" +
                            resultados.getString("iban")  + "\t|\t" +
                            resultados.getDouble("balance") + "\t|\t" +
                            resultados.getInt("clientid")
                    );
                }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Muestra cliente
    public static Client muestraCliente(MongoCollection<Client> collection, int idCLiente){

        return collection.find(eq("clientid", idCLiente)).first();

    }

    // Muestra cuentas
    public static List<Account> muestraTodasCuentas(Connection conexion){

        List<Account> listaCuentas = new ArrayList<Account>();

        String consultaSQL = "SELECT * FROM accounts";
        try {
            PreparedStatement consulta = conexion.prepareStatement(consultaSQL);

            ResultSet resultados = consulta.executeQuery();

            while(resultados.next()){
                listaCuentas.add(new Account(
                        resultados.getInt("accountid"),
                        resultados.getString("iban"),
                        resultados.getDouble("balance"),
                        resultados.getInt("clientid")
                ));
            }

            return listaCuentas;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Muestra clientes
    public static void muestraTodosClientes(MongoCollection<Client> collection){
        List<Client> listaClientes = new ArrayList<Client>();
    }

    // Transacción
    public static void transaction(Connection conexion, String idCuentaOrigen, String idCuentaDestino, double cantidadTransferencia){

        String consultaSQLRestaCuentaOrigen = "UPDATE accounts " +
                "SET balance = ?, " +
                "WHERE iban = ?";

        String consultaSQLSumaCuentaDestino = "UPDATE accounts " +
                "SET balance = ?, " +
                "WHERE iban = ?";

        try {
            PreparedStatement consultaRestaCuentaOrigen = conexion.prepareStatement(consultaSQLRestaCuentaOrigen);
            PreparedStatement consultaSumaCuentaDestino = conexion.prepareStatement(consultaSQLSumaCuentaDestino);

//            consultaRestaCuentaOrigen.setDouble(1, cuentaModificada.getIban());
//            consultaRestaCuentaOrigen.setDouble(2, cuentaModificada.getBalance());
//            consultaSumaCuentaDestino.setInt(1, cuentaModificada.getClientid());
//            consultaSumaCuentaDestino.setInt(2, idCuenta);
//
//            consultaRestaCuentaOrigen.executeUpdate();
//            consultaSumaCuentaDestino.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

}
